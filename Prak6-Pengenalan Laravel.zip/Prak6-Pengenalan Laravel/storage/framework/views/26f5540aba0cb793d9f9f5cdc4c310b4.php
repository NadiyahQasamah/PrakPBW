<!DOCTYPE html>
<html>
<head>
    <title>Selamat Datang</title>
</head>
<body>
    <h1>Selamat Datang di Buku Tamu</h1>
    <a href="<?php echo e(route('bukutamu.create')); ?>">Isi Buku Tamu</a> |
    <a href="<?php echo e(route('bukutamu.show')); ?>">Lihat Komentar</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\belajar-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>